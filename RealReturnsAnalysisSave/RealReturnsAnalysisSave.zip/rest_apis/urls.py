from django.urls import path
from rest_apis.views import admin_apis, user_apis

app_name = "rest_apis"

urlpatterns = []
